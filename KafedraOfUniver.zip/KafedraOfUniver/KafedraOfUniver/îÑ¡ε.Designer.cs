﻿namespace KafedraOfUniver
{
    partial class Меню
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.завКафедрыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.нагрузкаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.контингентToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.планКафедрыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.отчётToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.нАзначениеМестПрактикиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.преподавательToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.кураторToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.студентToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.выходToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.label1 = new System.Windows.Forms.Label();
            this.учетКонтингентаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.расписаниеКонсультацийToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.отчетToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.учётКонтингентаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.выпускСтудентовToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.SteelBlue;
            this.menuStrip1.Dock = System.Windows.Forms.DockStyle.Left;
            this.menuStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Visible;
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.завКафедрыToolStripMenuItem,
            this.преподавательToolStripMenuItem,
            this.кураторToolStripMenuItem,
            this.студентToolStripMenuItem,
            this.выходToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(164, 610);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // завКафедрыToolStripMenuItem
            // 
            this.завКафедрыToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.нагрузкаToolStripMenuItem,
            this.контингентToolStripMenuItem,
            this.планКафедрыToolStripMenuItem,
            this.отчётToolStripMenuItem,
            this.нАзначениеМестПрактикиToolStripMenuItem});
            this.завКафедрыToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.завКафедрыToolStripMenuItem.Name = "завКафедрыToolStripMenuItem";
            this.завКафедрыToolStripMenuItem.Size = new System.Drawing.Size(157, 29);
            this.завКафедрыToolStripMenuItem.Text = "Зав.Кафедры";
            // 
            // нагрузкаToolStripMenuItem
            // 
            this.нагрузкаToolStripMenuItem.Name = "нагрузкаToolStripMenuItem";
            this.нагрузкаToolStripMenuItem.Size = new System.Drawing.Size(335, 30);
            this.нагрузкаToolStripMenuItem.Text = "Нагрузка";
            this.нагрузкаToolStripMenuItem.Click += new System.EventHandler(this.нагрузкаToolStripMenuItem_Click);
            // 
            // контингентToolStripMenuItem
            // 
            this.контингентToolStripMenuItem.Name = "контингентToolStripMenuItem";
            this.контингентToolStripMenuItem.Size = new System.Drawing.Size(335, 30);
            this.контингентToolStripMenuItem.Text = "Контингент";
            this.контингентToolStripMenuItem.Click += new System.EventHandler(this.контингентToolStripMenuItem_Click);
            // 
            // планКафедрыToolStripMenuItem
            // 
            this.планКафедрыToolStripMenuItem.Name = "планКафедрыToolStripMenuItem";
            this.планКафедрыToolStripMenuItem.Size = new System.Drawing.Size(335, 30);
            this.планКафедрыToolStripMenuItem.Text = "План кафедры";
            this.планКафедрыToolStripMenuItem.Click += new System.EventHandler(this.планКафедрыToolStripMenuItem_Click);
            // 
            // отчётToolStripMenuItem
            // 
            this.отчётToolStripMenuItem.Name = "отчётToolStripMenuItem";
            this.отчётToolStripMenuItem.Size = new System.Drawing.Size(335, 30);
            this.отчётToolStripMenuItem.Text = "Отчёт";
            this.отчётToolStripMenuItem.Click += new System.EventHandler(this.отчётToolStripMenuItem_Click);
            // 
            // нАзначениеМестПрактикиToolStripMenuItem
            // 
            this.нАзначениеМестПрактикиToolStripMenuItem.Name = "нАзначениеМестПрактикиToolStripMenuItem";
            this.нАзначениеМестПрактикиToolStripMenuItem.Size = new System.Drawing.Size(333, 30);
            this.нАзначениеМестПрактикиToolStripMenuItem.Text = "Назначение мест практики";
            this.нАзначениеМестПрактикиToolStripMenuItem.Click += new System.EventHandler(this.нАзначениеМестПрактикиToolStripMenuItem_Click);
            // 
            // преподавательToolStripMenuItem
            // 
            this.преподавательToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.учетКонтингентаToolStripMenuItem,
            this.расписаниеКонсультацийToolStripMenuItem,
            this.отчетToolStripMenuItem});
            this.преподавательToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.преподавательToolStripMenuItem.Name = "преподавательToolStripMenuItem";
            this.преподавательToolStripMenuItem.Size = new System.Drawing.Size(157, 29);
            this.преподавательToolStripMenuItem.Text = "Преподаватель";
            // 
            // кураторToolStripMenuItem
            // 
            this.кураторToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.учётКонтингентаToolStripMenuItem,
            this.выпускСтудентовToolStripMenuItem});
            this.кураторToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.кураторToolStripMenuItem.Name = "кураторToolStripMenuItem";
            this.кураторToolStripMenuItem.Size = new System.Drawing.Size(157, 29);
            this.кураторToolStripMenuItem.Text = "Куратор";
            // 
            // студентToolStripMenuItem
            // 
            this.студентToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.студентToolStripMenuItem.Name = "студентToolStripMenuItem";
            this.студентToolStripMenuItem.Size = new System.Drawing.Size(157, 29);
            this.студентToolStripMenuItem.Text = "Студент";
            this.студентToolStripMenuItem.Click += new System.EventHandler(this.студентToolStripMenuItem_Click);
            // 
            // выходToolStripMenuItem
            // 
            this.выходToolStripMenuItem.BackColor = System.Drawing.Color.Salmon;
            this.выходToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.выходToolStripMenuItem.Name = "выходToolStripMenuItem";
            this.выходToolStripMenuItem.Size = new System.Drawing.Size(157, 29);
            this.выходToolStripMenuItem.Text = "Выход";
            this.выходToolStripMenuItem.Click += new System.EventHandler(this.выходToolStripMenuItem_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 22F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(427, 260);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(541, 42);
            this.label1.TabIndex = 2;
            this.label1.Text = "Добро пожаловать в систему!";
            // 
            // учетКонтингентаToolStripMenuItem
            // 
            this.учетКонтингентаToolStripMenuItem.Name = "учетКонтингентаToolStripMenuItem";
            this.учетКонтингентаToolStripMenuItem.Size = new System.Drawing.Size(326, 30);
            this.учетКонтингентаToolStripMenuItem.Text = "Расписание занятий";
            this.учетКонтингентаToolStripMenuItem.Click += new System.EventHandler(this.учетКонтингентаToolStripMenuItem_Click);
            // 
            // расписаниеКонсультацийToolStripMenuItem
            // 
            this.расписаниеКонсультацийToolStripMenuItem.Name = "расписаниеКонсультацийToolStripMenuItem";
            this.расписаниеКонсультацийToolStripMenuItem.Size = new System.Drawing.Size(326, 30);
            this.расписаниеКонсультацийToolStripMenuItem.Text = "Расписание консультаций";
            this.расписаниеКонсультацийToolStripMenuItem.Click += new System.EventHandler(this.расписаниеКонсультацийToolStripMenuItem_Click);
            // 
            // отчетToolStripMenuItem
            // 
            this.отчетToolStripMenuItem.Name = "отчетToolStripMenuItem";
            this.отчетToolStripMenuItem.Size = new System.Drawing.Size(326, 30);
            this.отчетToolStripMenuItem.Text = "Отчет";
            this.отчетToolStripMenuItem.Click += new System.EventHandler(this.отчетToolStripMenuItem_Click);
            // 
            // учётКонтингентаToolStripMenuItem
            // 
            this.учётКонтингентаToolStripMenuItem.Name = "учётКонтингентаToolStripMenuItem";
            this.учётКонтингентаToolStripMenuItem.Size = new System.Drawing.Size(251, 30);
            this.учётКонтингентаToolStripMenuItem.Text = "Учёт контингента";
            this.учётКонтингентаToolStripMenuItem.Click += new System.EventHandler(this.учётКонтингентаToolStripMenuItem_Click);
            // 
            // выпускСтудентовToolStripMenuItem
            // 
            this.выпускСтудентовToolStripMenuItem.Name = "выпускСтудентовToolStripMenuItem";
            this.выпускСтудентовToolStripMenuItem.Size = new System.Drawing.Size(251, 30);
            this.выпускСтудентовToolStripMenuItem.Text = "Выпуск студентов";
            this.выпускСтудентовToolStripMenuItem.Click += new System.EventHandler(this.выпускСтудентовToolStripMenuItem_Click);
            // 
            // Меню
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1203, 610);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Меню";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Меню";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem завКафедрыToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem преподавательToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem кураторToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem студентToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem нагрузкаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem контингентToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem планКафедрыToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem отчётToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem нАзначениеМестПрактикиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem выходToolStripMenuItem;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ToolStripMenuItem учетКонтингентаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem расписаниеКонсультацийToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem отчетToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem учётКонтингентаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem выпускСтудентовToolStripMenuItem;
    }
}