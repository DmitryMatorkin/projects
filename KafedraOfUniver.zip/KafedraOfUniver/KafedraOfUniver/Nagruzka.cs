﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KafedraOfUniver
{
    public partial class Nagruzka : Form
    {
        public Nagruzka()
        {
            InitializeComponent();
        }

        private void выходToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        void PrintPageHandler(object sender, PrintPageEventArgs e)
        {
         

        }

        private void button4_Click(object sender, EventArgs e)
        {
            PrintDocument printDocument = new PrintDocument();
            printDocument.PrintPage += PrintPageHandler;
            PrintDialog printDialog = new PrintDialog();
            printDialog.Document = printDocument;
            if (printDialog.ShowDialog() == DialogResult.OK)
                printDialog.Document.Print();
        }

        private void выходToolStripMenuItem1_Click(object sender, EventArgs e)
        {
           
        }

        private void контингентToolStripMenuItem_Click(object sender, EventArgs e)
        {
            KontStud kontStud = new KontStud();
            kontStud.Show();
            this.Close();
        }

        private void планКафедрыToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Plan plan = new Plan();
            plan.Show();
            this.Close();
        }

        private void отчётToolStripMenuItem_Click(object sender, EventArgs e)
        {
            otchetZav otchetZav = new otchetZav();
            otchetZav.Show();
            this.Close();
        }

        private void нАзначениеМестПрактикиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Praktik praktik = new Praktik();
            praktik.Show();
            this.Close();
        }
    }
}
