﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KafedraOfUniver
{
    public partial class Меню : Form
    {
        public Меню()
        {
            InitializeComponent();
        }

        private void toolStripLabel1_Click(object sender, EventArgs e)
        {
            Form1 form = new Form1();
            form.ShowDialog();
        }

        private void нагрузкаToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Nagruzka nagruzka = new Nagruzka();
            nagruzka.ShowDialog();
            
        }

        private void менюToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void планКафедрыToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Plan plan = new Plan();
            plan.ShowDialog();
            
        }

        private void выходToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
           
        }

        private void контингентToolStripMenuItem_Click(object sender, EventArgs e)
        {
            KontStud kont = new KontStud();
            kont.ShowDialog();
            
        }

        private void отчётToolStripMenuItem_Click(object sender, EventArgs e)
        {
            otchetZav otchetZav = new otchetZav();
            otchetZav.ShowDialog();
           
        }

        private void нАзначениеМестПрактикиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Praktik praktik = new Praktik();
                praktik.ShowDialog();
           
        }

        private void учетКонтингентаToolStripMenuItem_Click(object sender, EventArgs e)
        {
            расписаниезанятий raspz = new расписаниезанятий();
            raspz.Show();
        }

        private void расписаниеКонсультацийToolStripMenuItem_Click(object sender, EventArgs e)
        {
            расписаниеконсультаций raspk = new расписаниеконсультаций();
            raspk.Show();
        }

        private void отчетToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ОтчетПрепод otchp = new ОтчетПрепод();
            otchp.Show();
        }

        private void учётКонтингентаToolStripMenuItem_Click(object sender, EventArgs e)
        {
            KontStud kontStud = new KontStud();
            kontStud.Show();

        }

        private void выпускСтудентовToolStripMenuItem_Click(object sender, EventArgs e)
        {
            vypusk vypusk = new vypusk();
            vypusk.Show();
        }

        private void студентToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Student student = new Student();
            student.Show();
        }
    }
}
