﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KafedraOfUniver
{
    public partial class otchetZav : Form
    {
        public otchetZav()
        {
            InitializeComponent();
        }
        void PrintPageHandler(object sender, PrintPageEventArgs e)
        {


        }

        private void button4_Click(object sender, EventArgs e)
        {
            PrintDocument printDocument = new PrintDocument();
            printDocument.PrintPage += PrintPageHandler;
            PrintDialog printDialog = new PrintDialog();
            printDialog.Document = printDocument;
            if (printDialog.ShowDialog() == DialogResult.OK)
                printDialog.Document.Print();
        }

        private void выходToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Form1 form = new Form1();
            form.ShowDialog();
            this.Close();
        }

        private void выходToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }
       

        private void нагрузкаToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            Nagruzka nagr = new Nagruzka();
            nagr.Show();
            this.Close();
        }

        private void контингентToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            KontStud kontStud = new KontStud();
            kontStud.Show();
            this.Close();

        }

        private void планКафедрыToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            Plan plan = new Plan();
            plan.Show();
            this.Close();
        }

        private void нАзначениеМестПрактикиToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            Praktik praktik = new Praktik();
            praktik.Show();
            this.Close();
        }
    }
}
